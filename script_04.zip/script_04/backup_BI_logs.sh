#!/bin/bash
# Archive BigInsights Servers Logs (BI Eco-system, DB2 & Unix)
# Author - Vishal Garg
# Copyright (C) 2013, 2014 IBM Corp. All rights reserved.:
#################################################################

##DEFINING VARIABLES
today=$(date +"%m%d%Y")
executeTime=$(date+"%m%d%y%H%M")
script_dir=/home/biadmin/scripts
backupDir=/hadoop/disk5
nfsbackupDir=/hadoop/backup/
##

cd ${backupDir}
echo "CREATE ${today} DIRECTORY.." >> `hostname`_${today}.log
mkdir -p ${today}

#cd ${today}
echo "GATHERING LOG DIRECTORIES LIST.." >> `hostname`_${today}.log

while read line
do
  sudo cp $line/* ${backupDir}/${today}/
done < ${script_dir}/logs_directories

echo "ARCHIVING TAR.." >> `hostname`_${today}.log
sudo tar -zcvf `hostname`_${today}.tar.gz ${backupDir}/${today}/

echo "TRANSFERRING LOGS TO BI EXPORT SERVER.." >> `hostname`_${today}.log
scp ${backupDir}/`hostname`_${today}.tar.gz timvr007.nonprod.tdefap.com:${nfsbackupDir}/${today}

if [ $? -eq 0 ]
then
echo "REMOVING ARCHIVE FILES FROM ${backupDir}/${today} .." >> `hostname`_${today}.log
rm -r ${backupDir}/${today}
else
echo "FILES NOT COPIED TO NFS.." >> >> `hostname`_${today}.log
fi



#sudo /usr/bin/rsync --dry-run -e ssh -avz /hadoop/disk5   biadmin@mmspr003.tdefap.com:/hadoop/${today}/${BI_Type}_Cluster/

exit 
path=$(echo ${line} | sed -e 's/\//_/g')