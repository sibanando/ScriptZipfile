#!/bin/bash

old_sp="siba"
new_sp="siba01"

while true; do
  read -p "Make sure to keep all the setup files under directory /root/backup/MEP.6.1/ including this script and then run. Are you sure everything under mentioned directory and continue to run the script?" yn
  case $yn in
    [Yy]* ) echo "Starting the $0 script `date`"; break;;
    [Nn]* ) exit;;
    * ) echo "Please answer yes or no.";;
  esac
done

/bin/sleep 1
echo ""

if [ $1 == 'siba' ]
then
echo "$old_sp  am in."
elif [ $1 == b ]
then
echo "entered 2"
else 
echo "It is exited ,not mentioned the servers "
fi

