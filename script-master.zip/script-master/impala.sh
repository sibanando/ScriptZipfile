#!/bin/bash

###Make backup directory to store impala config file########

clush -b -g prod “ mkdir /root/backup”
clush -b -g prod “ chmod 755 /root/backup”


clush -b -g prod "find /opt/mapr -type d -name impala\* -exec cp --parent  -r  \{\} /root/backup \;" 

###clush -b -g prod ‘ yum update -y mapr-\*’###
####Update or upgrade impala#####

clush -b -g prod ‘yum update -y mapr-impala-\*’
cd /root/backup/impala/impala-2.10.0/conf
clush -bg prod --copy hive-site.xml env.sh set_path_env.sh --dest /opt/mapr/impala/impala-2.10.0/conf/

###run configure.sh####

/opt/mapr/server/configure.sh -R 