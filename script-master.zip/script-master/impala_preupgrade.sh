#!/bin/bash

###Make backup directory to store impala config file########
old_imp="impala-2.10.0"

mkdir /root/backup/MEP.6.1/$old_imp
chmod 755 /root/backup/MEP.6.1/$old_imp


####find /opt/mapr -type d -name impala\* -exec cp --parent  -r  \{\} /root/backup \; ###

cp -rp /opt/mapr/impala/$old_imp/conf/* /root/backup/MEP.6.1/$old_imp

 