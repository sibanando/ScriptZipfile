#!/bin/bash

###clush -b -g prod ‘ yum update -y mapr-\*’###
old_imp="impala-2.10.0"
new_imp="2.12.0.100"
while true; do
  read -p "Make sure to keep all the setup files under directory /root/backup/MEP.6.1/ including this script and then run. Are you sure everything under mentioned directory and continue to run the script?" yn
  case $yn in
    [Yy]* ) echo "Starting the $0 script `date`"; break;;
    [Nn]* ) exit;;
    * ) echo "Please answer yes or no.";;
  esac
done

/bin/sleep 1
echo ""

####Update or upgrade impala#####

yum update -y mapr-impala-\*

###Backup the new conf######
mkdir /root/backup/MEP.6.1/$old_imp/newconf/
cp /opt/mapr/impala/$new_imp/conf/* /root/backup/MEP.6.1/$old_imp/newconf/

####Copies config files#####
cd /root/backup/MEP.6.1/$old_imp/
cp -rp hive-site.xml env.sh set_path_env.sh /opt/mapr/impala/$new_imp/conf/

###run configure.sh####

/opt/mapr/server/configure.sh -R 