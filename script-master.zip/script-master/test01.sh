#!/bin/bash

#echo -n "What's your name: "
echo  "What's your name: "
read x
echo $x
