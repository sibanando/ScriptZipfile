#!/bin/bash
###esekilx5645.rnd.ki.sw.ericsson.se & esekilx5646.rnd.ki.sw.ericsson.se###
###clush -b -g prod ‘ yum update -y mapr-\*’###
####Update or upgrade ELK##########

yum update -y mapr-kibana 

###Creating the folder which is not created as per Doc######

mkdir -p /opt/mapr/kibana/kibana-6.2.3/config/ca/
chown -R mapr:maprg /opt/mapr/kibana/kibana-6.2.3/config/ca/
mkdir -p /opt/mapr/kibana/kibana-6.2.3/config/certs/
chown -R mapr:maprg /opt/mapr/kibana/kibana-6.2.3/config/certs/


###Copies the required kibana conf files#####

SS
cd /root/backup/MEP.6.1/kibana-6.2.3/

#####List the files####
ls -ltr


cp .keystore_password   /opt/mapr/kibana/kibana-6.2.3/config/
cp es-root-ca.pem   /opt/mapr/kibana/kibana-6.2.3/config/ca/
cp kibanaserver-usr-clientCombo.pem  /opt/mapr/kibana/kibana-6.2.3/config/certs/
cp kibanaserver-usr-signed.pem  /opt/mapr/kibana/kibana-6.2.3/config/certs/
cp kibanaserver-usr-private-key.pem  /opt/mapr/kibana/kibana-6.2.3/config/certs/


###run configure.sh####

/opt/mapr/server/configure.sh -R