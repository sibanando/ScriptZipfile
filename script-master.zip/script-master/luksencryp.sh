#!/bin/bash
 
#yum -y install cryptsetup
#yum -y update device-mapper
# timestamp="$(date +%Y-%m-%d.%H:%M:%S)"
 
#mv -v /etc/crypto /etc/crypto."$timestamp"
mkdir -p /etc/crypto
chmod -R go-rw /etc/crypto
 
#mv -v /etc/crypttab /etc/crypttab."$timestamp"
#mv -v /opt/mapr/disks.txt /opt/mapr/disks.txt."$timestamp"
tr -dc '[:graph:]' < /dev/random | head -c "${1:-512}" > /etc/crypto/lukskey.bin
chmod go-rw /etc/crypto/lukskey.bin
 
disks="sda sdb sdc sdd sde sdf sdg sdh sdi sdj sdk sdl sdm sdn sdo sdp"
for f in $disks
do
#  rm -fv /etc/crypto/"$f"-key.bin
#   cryptsetup close luks-"$f"
  cryptsetup --batch-mode --use-random luksFormat /dev/"$f" /etc/crypto/lukskey.bin
  cryptsetup luksOpen /dev/"$f" luks-"$f" < /etc/crypto/lukskey.bin
  echo  luks-"$f" /dev/"$f" /etc/crypto/lukskey.bin >> /etc/crypttab
  echo  /dev/mapper/luks-"$f" >> /root/setup_files/disks.txt
done
#echo "Backup files created..."
#ls -l {/etc/crypto."$timestamp",/etc/crypttab."$timestamp",/opt/mapr/disks.txt."$timestamp"}
