#!/bin/bash

###clush -b -g prod ‘ yum update -y mapr-\*’###
####Update or upgrade ELK##########

yum update -y mapr-fluentd 

###Creating the folder which is not created as per Doc######

mkdir -p /opt/mapr/fluentd/fluentd-1.1.2/etc/fluentd/certs/
chown -R mapr:maprg /opt/mapr/fluentd/fluentd-1.1.2/etc/fluentd/certs/
mkdir -p /opt/mapr/fluentd/fluentd-1.1.2/etc/fluentd/ca/
chown -R mapr:maprg /opt/mapr/fluentd/fluentd-1.1.2/etc/fluentd/ca/

cd /root/backup/MEP.6.1/fluentd-1.1.2/

#####List the files####
ls -ltr

###Copies the required fluentd conf files#####

cp es-root-ca.pem /opt/mapr/fluentd/fluentd-1.1.2/etc/fluentd/ca/
cp fluentd-usr-signed.pem /opt/mapr/fluentd/fluentd-1.1.2/etc/fluentd/certs/
cp fluentd-usr-private-key.pem  /opt/mapr/fluentd/fluentd-1.1.2/etc/fluentd/certs/
cp fluentd-usr-private-key.pem  /opt/mapr/fluentd/fluentd-1.1.2/etc/fluentd/certs/


###run configure.sh####

/opt/mapr/server/configure.sh -R