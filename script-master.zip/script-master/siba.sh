#!/bin/bash

while true; do
  read -p "Make sure to keep all the setup files under directory $_dir including this script and then run. Are you sure everything under mentioned directory and continue to run the script?" yn
  case $yn in
    [Yy]* ) echo "Starting the $0 script `date`"; break;;
    [Nn]* ) exit;;
    * ) echo "Please answer yes or no.";;
  esac
done

/bin/sleep 1
echo ""

echo "idontknow: $0"
echo "First arg: $1"
echo "First arg: $2"
x=$1
echo $x
mkdir /ssiba01
cd /ssiba01
pwd

echo "idontknow: $@"
