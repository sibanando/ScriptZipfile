for i in /home/ken/LOGFILES/log_file*.txt

do

rm -f $i

done

