#!/bin/bash
####esekilx5645.rnd.ki.sw.ericsson.se &esekilx5646.rnd.ki.sw.ericsson.se####
###clush -b -g prod ‘ yum update -y mapr-\*’###
while true; do
  read -p "Make sure to keep all the setup files under directory /root/backup/MEP.6.1/ including this script and then run. Are you sure everything under mentioned directory and continue to run the script?" yn
  case $yn in
    [Yy]* ) echo "Starting the $0 script `date`"; break;;
    [Nn]* ) exit;;
    * ) echo "Please answer yes or no.";;
  esac
done

/bin/sleep 1
echo ""

if [ $1 == 'esekilx5645.rnd.ki.sw.ericsson.se' ]
then
echo "I am in."

####Update or upgrade ELK##########

yum update -y mapr-kibana 

###Backup the new conf######
mkdir /root/backup/MEP.6.1/kibana-6.2.3/newconf/
cp /opt/mapr/kibana/kibana-6.2.3/* /root/backup/MEP.6.1/kibana-6.2.3/newconf/

###Creating the folder which is not created as per Doc######

mkdir -p /opt/mapr/kibana/kibana-6.2.3/config/ca/
chown -R mapr:maprg /opt/mapr/kibana/kibana-6.2.3/config/ca/
mkdir -p /opt/mapr/kibana/kibana-6.2.3/config/certs/
chown -R mapr:maprg /opt/mapr/kibana/kibana-6.2.3/config/certs/


###Copies the required kibana conf files#####

cd /root/backup/MEP.6.1/kibana-6.2.3/

#####List the files####
ls -ltr


cp .keystore_password   /opt/mapr/kibana/kibana-6.2.3/config/
cp es-root-ca.pem   /opt/mapr/kibana/kibana-6.2.3/config/ca/
cp kibanaserver-usr-clientCombo.pem  /opt/mapr/kibana/kibana-6.2.3/config/certs/
cp kibanaserver-usr-signed.pem  /opt/mapr/kibana/kibana-6.2.3/config/certs/
cp kibanaserver-usr-private-key.pem  /opt/mapr/kibana/kibana-6.2.3/config/certs/

elif [ $1 == 'esekilx5646.rnd.ki.sw.ericsson.se' ]
then
echo "entered 2"
####Update or upgrade ELK##########

yum update -y mapr-kibana 

###Backup the new conf######
mkdir /root/backup/MEP.6.1/kibana-6.2.3/newconf/
cp /opt/mapr/kibana/kibana-6.2.3/* /root/backup/MEP.6.1/kibana-6.2.3/newconf/

###Creating the folder which is not created as per Doc######

mkdir -p /opt/mapr/kibana/kibana-6.2.3/config/ca/
chown -R mapr:maprg /opt/mapr/kibana/kibana-6.2.3/config/ca/
mkdir -p /opt/mapr/kibana/kibana-6.2.3/config/certs/
chown -R mapr:maprg /opt/mapr/kibana/kibana-6.2.3/config/certs/


###Copies the required kibana conf files#####

cd /root/backup/MEP.6.1/kibana-6.2.3/

#####List the files####
ls -ltr


cp .keystore_password   /opt/mapr/kibana/kibana-6.2.3/config/
cp es-root-ca.pem   /opt/mapr/kibana/kibana-6.2.3/config/ca/
cp kibanaserver-usr-clientCombo.pem  /opt/mapr/kibana/kibana-6.2.3/config/certs/
cp kibanaserver-usr-signed.pem  /opt/mapr/kibana/kibana-6.2.3/config/certs/
cp kibanaserver-usr-private-key.pem  /opt/mapr/kibana/kibana-6.2.3/config/certs/
else
echo "I am out."
fi
