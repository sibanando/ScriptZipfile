#!/bin/bash
 
echo -n "What's your name: "
 
read name
 
echo "Hi $name,"
