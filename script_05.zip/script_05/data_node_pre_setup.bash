#!/bin/bash
##########################################
# Setup Script of Data Node for RedHat 7
# Created - 03/04/2018
##########################################

_dir="/root/setup_files"

# Documents permissions
_fp="600"
 
# MapR user/group
_mapru="mapr"
_maprg="maprg"
_mapruid="123400016"
_maprgid="123406010"

while true; do
  read -p "Make sure to keep all the setup files under directory $_dir including this script and then run. Are you sure everything under mentioned directory and continue to run the script?" yn
  case $yn in
    [Yy]* ) echo "Starting the $0 script `date`"; break;;
    [Nn]* ) exit;;
    * ) echo "Please answer yes or no.";;
  esac
done

/bin/sleep 1
echo ""

# Putting in trigger file to make sure script is not run more than once
if [ -f $_dir/prescript.run ]; then
echo "
############### WARNING ###############
This script was already executed.
Don't run this script more than once
The script is ending now
############### WARNING ###############"
exit 1
else
echo "First time running script $0"
fi
echo ""

# Storage encryption Section
echo "Configure encrypted storage with LUKS using exportable keys start."
/bin/bash $_dir/luksencryp.sh
echo "Configure encrypted storage with LUKS using exportable keys end."

/bin/sleep 5
echo ""

# Create shadow group
echo "Start create shadow group"
groupadd -g 5002 shadow
chmod 440 /etc/shadow
chown root:shadow /etc/shadow
echo "End create shadow group"
echo ""

# Users Creation Section
echo "Start User Creation Section"
groupadd -g $_maprgid $_maprg
useradd -m -u $_mapruid -g $_maprgid -p '$6$GzlcP5ei$E6P9QM40O6KJFLZ3wMcg3jzQBNxGXrf8yc77CbCmf0KtFSxK0mpCParhc3WVNEAm4fHKPAqyRV9rsiF6DAFlW0' -G $(stat -c '%G' /etc/shadow) $_mapru
echo "End User Creation Section"
echo ""

# Chanage MapR password
echo "Start change mapr user password"
echo "mapr:Had00p!" | chpasswd
echo "End change mapr user password"
echo ""

# Add hosts
#echo "Add hosts start"
#/bin/cp $_dir/hosts /etc/hosts
#echo "Add hosts end"
#echo ""

# Install Oracle JAVA
echo "Install oracle JAVA"
yum localinstall -y $_dir/jdk-8u161-linux-x64.rpm
export JAVA_HOME=/usr/java/jdk1.8.0_161/
export JRE_HOME=/usr/java/jdk1.8.0_161/jre
export PATH=$PATH:$HOME/bin:$JAVA_HOME/bin:$JRE_HOME/bin
echo "Done with java"
echo ""

# Enable JAVA crypto.policy
echo "Enable JAVA crypto.policy start"
/bin/cp /usr/java/jdk1.8.0_161/jre/lib/security/java.security $_dir/java.security.original
/bin/cp $_dir/java.security /usr/java/jdk1.8.0_161/jre/lib/security
echo "Enable JAVA crypto.policy end"
echo ""

#echo "Set up ssh keys"
#/bin/cp $_dir/authorized_keys /root/.ssh/authorized_keys
#/bin/cp $_dir/id_rsa /root/.ssh/id_rsa
#/bin/cp $_dir/id_rsa.pub /root/.ssh/id_rsa.pub
#chmod $_fp /root/.ssh/authorized_keys
#chmod $_fp /root/.ssh/id_rsa
#echo "Done with ssh keys"
#echo ""


# Setting up trigger file, as to not allow the script to run again
echo "Creating Trigger File $_dir/prescript.run"
/bin/touch $_dir/prescript.run
echo "Done with trigger file"
echo ""

# Change /etc/profile section
echo "Appending to /etc/profile"
echo 'export HIVE_HOME=/opt/mapr/hive/hive-2.1
export JAVA_HOME=/usr/java/jdk1.8.0_161/
export JRE_HOME=/usr/java/jdk1.8.0_161/jre
export PATH=$PATH:$HOME/bin:$JAVA_HOME/bin:$JRE_HOME/bin' >> /etc/profile

source /etc/profile
echo "Done with /etc/profile"
echo ""

# Change /etc/sysctl.conf section
echo "Set up swappiness, appending to /etc/sysctl.conf"
echo "vm.swappiness=10
net.ipv4.tcp_retries2=5
vm.overcommit_memory=0
net.core.rmem_max=4194304
net.core.rmem_default=1048576
net.core.wmem_max=4194304
net.core.wmem_default=1048576
net.core.netdev_max_backlog=30000
net.ipv4.tcp_rmem=4096 1048576 4194304
net.ipv4.tcp_wmem=4096 1048576 4194304
net.ipv4.tcp_mem=8388608 8388608 8388608
net.ipv4.tcp_syn_retries=4
vm.dirty_ratio=6
vm.dirty_background_ratio=3
fs.aio-max-nr=262144" >> /etc/sysctl.conf
echo "Done with swappiness"
echo ""