#!/bin/bash
##########################################
# Setup Script of Data Node for RedHat 7
# Created - 03/04/2018
##########################################

_dir="/root/setup_files"

# Documents permissions
_fp="600"
 
# MapR user/group
_mapru="mapr"
_maprg="maprg"
_mapruid="123400016"
_maprgid="123406010"

while true; do
  read -p "Make sure to keep all the setup files under directory $_dir including this script and then run. Are you sure everything under mentioned directory and continue to run the script?" yn
  case $yn in
    [Yy]* ) echo "Starting the $0 script `date`"; break;;
    [Nn]* ) exit;;
    * ) echo "Please answer yes or no.";;
  esac
done

/bin/sleep 1
echo ""

# Putting in trigger file to make sure script is not run more than once
if [ -f $_dir/postscript.run ]; then
echo "
############### WARNING ###############
This script was already executed.
Don't run this script more than once
The script is ending now
############### WARNING ###############"
exit 1
else
echo "First time running script $0"
fi
echo ""

# Setup mapr_core.repo
echo "Setup mapr_core.repo"
echo "[mapr_core]" > /etc/yum.repos.d/mapr_core.repo
echo "name=MapR Technologies, Inc.
baseurl=http://esekilxgp01/yum/base/mapr_core/
enabled=1
gpgcheck=1
proxy=_none_" >> /etc/yum.repos.d/mapr_core.repo
echo "Done with mapr_core repo setup"
echo ""

# Setup mapr_ecosystem.repo
echo "Setup mapr_ecosystem.repo"
echo "[mapr_ecosystem]" > /etc/yum.repos.d/mapr_ecosystem.repo
echo "name=MapR Technologies, Inc.
baseurl=http://esekilxgp01/yum/base/mapr_eco/
enabled=1
gpgcheck=1
proxy=_none_" >> /etc/yum.repos.d/mapr_ecosystem.repo
echo "Done with mapr_ecosystem repo setup"
echo ""

# Install the MapR Package Key
echo "Installing MapR Package Key"
rpm --import http://package.mapr.com/releases/pub/maprgpg.key
yum clean all
echo "Done MapR Package Key"
echo ""

# Install MapR core packages for data node
echo "Installing MapR core packages for data node"
yum install -y mapr-core mapr-fileserver mapr-nfs mapr-nodemanager mapr-ericsson
echo "Done installing mapr core packages for data node"
echo ""

# mapr mfs mount
echo "Setup for mapr mfs mount"
mkdir /mapr
/bin/cp $_dir/mapr_fstab /opt/mapr/conf/mapr_fstab
echo "Done mapr mfs mount"
echo ""

# Setting up trigger file, as to not allow the script to run again
echo "Creating Trigger File $_dir/postscript.run"
/bin/touch $_dir/postscript.run
echo "Done with trigger file"
echo ""

# Setup MAPR_SUBNETS
echo "Setup MAPR_SUBNETS start"
/bin/cp $_dir/env_override.sh /opt/mapr/conf/env_override.sh
echo "Setup MAPR_SUBNETS end"
echo ""

# Set MapR environment variables
echo "Setup MapR environment variables env.sh"
/opt/mapr/conf/env.sh
echo "Done MapR environment variables env.sh"
echo ""

# Configuring Nodes with Security
echo "Configuring node with mapr security"
/bin/cp $_dir/maprserverticket /opt/mapr/conf/maprserverticket
chmod $_fp /opt/mapr/conf/maprserverticket
chown $_mapru:$_maprg /opt/mapr/conf/maprserverticket

/bin/cp $_dir/ssl_keystore /opt/mapr/conf/ssl_keystore
chmod $_fp /opt/mapr/conf/ssl_keystore
chown $_mapru:$_maprg /opt/mapr/conf/ssl_keystore

/bin/cp $_dir/ssl_truststore /opt/mapr/conf/ssl_truststore
chmod 644 /opt/mapr/conf/ssl_truststore
chown $_mapru:$_maprg /opt/mapr/conf/ssl_truststore

#cldb.key file seems not required to copy in nodes but as it's
#already copied in other nodes & present in ansible script so coping as well.
/bin/cp $_dir/cldb.key /opt/mapr/conf/cldb.key
chmod 644 /opt/mapr/conf/cldb.key
chown $_mapru:$_maprg /opt/mapr/conf/cldb.key

echo "Configuring node with mapr security end"
echo ""

# Configure cluter
echo "Configuring cluster"
/opt/mapr/server/configure.sh -secure -N rdiprod1 -u $_mapru -g $_maprg -C esekilx5643.rnd.ki.sw.ericsson.se,esekilx5644.rnd.ki.sw.ericsson.se,esekilx5645.rnd.ki.sw.ericsson.se -Z esekilx5640.rnd.ki.sw.ericsson.se,esekilx5641.rnd.ki.sw.ericsson.se,esekilx5642.rnd.ki.sw.ericsson.se -HS esekilx5634.rnd.ki.sw.ericsson.se -no-autostart
echo "done with mapr cluster configuration"
echo ""

# Set MapR environment variables again
echo "Setup MapR environment variables env.sh again"
/opt/mapr/conf/env.sh
echo "Done MapR environment variables env.sh again"
echo ""

# Configure cluter disks
echo "Configure cluter disks cluster"
/opt/mapr/server/disksetup -F -W 4 $_dir/disks.txt
echo "done with configure cluter disks"
echo ""

# Configure mapr login
echo "Configure mapr login start"
/bin/cp $_dir/mapr.login.conf /opt/mapr/conf
chown $_mapru:$_maprg /opt/mapr/conf/mapr.login.conf
echo "Configure mapr login end"
echo ""

# Start warden
echo "Starting warden"
service mapr-warden start
echo "Warden start done"

# Install MapR Metrics Monitoring
echo "Installing Metrics Monitoring"
yum install -y mapr-collectd mapr-fluentd
echo "Done installing Metrics Monitoring for data node"
echo ""

# Configure Elasticsearch & OpenTSDB
echo "Configure Elasticsearch & OpenTSDB start"
/opt/mapr/server/configure.sh -R -ES esekilx5645.rnd.ki.sw.ericsson.se,esekilx5646.rnd.ki.sw.ericsson.se -OT esekilx5643.rnd.ki.sw.ericsson.se,esekilx5644.rnd.ki.sw.ericsson.se
echo "Configure Elasticsearch & OpenTSDB end"
echo ""

# Install MapR ecosystem packages for data node
echo "Installing MapR ecosystem packages for data node"
yum install -y mapr-spark mapr-drill mapr-kafka mapr-impala mapr-impala-server mapr-hive
echo "Done installing mapr ecosystem packages for data node"
echo ""

# Run configure.sh
echo "Configure ecosystem components start"
/opt/mapr/server/configure.sh -R
echo "Configure ecosystem components end"
echo ""

# Configure Spark
echo "Configure Spark start"
/bin/cp $_dir/spark/spark-defaults.conf /opt/mapr/spark/spark-2.1.0/conf
/bin/cp $_dir/spark/hive-site.xml /opt/mapr/spark/spark-2.1.0/conf
chown -R $_mapru:$_maprg /opt/mapr/spark/spark-2.1.0/conf
echo "Configure Spark end"
echo ""

# Configure Drill
echo "Configure Drill start"
/bin/cp -R $_dir/drill/JPam-1.1 /opt
/bin/cp $_dir/drill/distrib-env.sh.prejmx /opt/mapr/drill/drill-1.11.0/conf
/bin/cp $_dir/drill/drill-env.sh /opt/mapr/drill/drill-1.11.0/conf
/bin/cp $_dir/drill/drill-override.conf /opt/mapr/drill/drill-1.11.0/conf
/bin/cp $_dir/drill/warden.drill-bits.conf /opt/mapr/conf/conf.d
chown -R $_mapru:$_maprg /opt/mapr/drill/drill-1.11.0/conf
chown $_mapru:$_maprg /opt/mapr/conf/conf.d/warden.drill-bits.conf
echo "Configure Drill end"
echo ""

# Configure Impala
echo "Configure Impala start"
/bin/cp $_dir/impala/env.sh /opt/mapr/impala/impala-2.7.0
/bin/cp $_dir/impala/env.sh /opt/mapr/impala/impala-2.7.0/conf
chown $_mapru:$_maprg /opt/mapr/impala/impala-2.7.0/env.sh
chown $_mapru:$_maprg /opt/mapr/impala/impala-2.7.0/conf/env.sh
echo "Configure Impala end"
echo ""

# Configure Hive
echo "Configure Hive start"
/bin/cp $_dir/hive/hive-site.xml /opt/mapr/hive/hive-2.1/conf
/bin/cp $_dir/hive/hive-env.sh /opt/mapr/hive/hive-2.1/conf
chown $_mapru:$_maprg /opt/mapr/hive/hive-2.1/conf
echo "Configure Hive end"
echo ""

# Configure yarn-site
echo "Configure yarn-site start"
/bin/cp $_dir/core-site.xml /opt/mapr/hadoop/hadoop-2.7.0/etc/hadoop
/bin/cp $_dir/yarn-site.xml /opt/mapr/hadoop/hadoop-2.7.0/etc/hadoop
chown $_mapru:root /opt/mapr/hadoop/hadoop-2.7.0/etc/hadoop/core-site.xml
chown $_mapru:root /opt/mapr/hadoop/hadoop-2.7.0/etc/hadoop/yarn-site.xml
echo "Configure yarn-site end"
echo ""

# Restart warden
echo "Restarting warden"
service mapr-warden restart
echo "Warden restart done"

/bin/sleep 3
echo ""

# Symlink users directory to MapRFS
echo "Symlink users directory to MapRFS start"
rm -rf /home/users
ln -s /mapr/rdiprod1/user /home/users
echo "Symlink users directory to MapRFS end"
echo ""