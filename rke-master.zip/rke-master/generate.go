// +build vendor

package main

import (
	_ "k8s.io/gengo/examples/deepcopy-gen"
)
