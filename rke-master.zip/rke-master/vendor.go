// +build vendor

package main

import (
	_ "github.com/go-bindata/go-bindata/go-bindata"
)

func main() {}
