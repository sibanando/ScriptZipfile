#!/bin/bash

/opt/mapr/server/configure.sh -ES esekilx5645.rnd.ki.sw.ericsson.se,esekilx5646.rnd.ki.sw.ericsson.se -R