#!/bin/bash

###clush -b -g prod ‘ yum update -y mapr-\*’###
####Update or upgrade ELK##########

yum update -y mapr-elasticsearch 

###Creating the folder which is not created as per Doc######

mkdir -p /opt/mapr/elasticsearch/elasticsearch-6.2.3/etc/elasticsearch/keystores
chown -R mapr:maprg /opt/mapr/elasticsearch/elasticsearch-6.2.3/etc/elasticsearch/keystores
mkdir -p /opt/mapr/elasticsearch/elasticsearch-6.2.3/etc/elasticsearch/certs
chown -R mapr:maprg /opt/mapr/elasticsearch/elasticsearch-6.2.3/etc/elasticsearch/certs
mkdir -p /opt/mapr/elasticsearch/elasticsearch-6.2.3/etc/elasticsearch/ca
chown -R mapr:maprg /opt/mapr/elasticsearch/elasticsearch-6.2.3/etc/elasticsearch/ca


###Copies the required elasticsearch conf files#####

SS
cd /root/backup/MEP.6.1/elasticsearch-6.2.3/

#####List the files####
ls -ltr


cp es-root-ca.pem   /opt/mapr/elasticsearch/elasticsearch-6.2.3/etc/elasticsearch/ca
cp admin-usr-private-key.pem   /opt/mapr/elasticsearch/elasticsearch-6.2.3/etc/elasticsearch/certs
cp admin-usr-signed.pem   /opt/mapr/elasticsearch/elasticsearch-6.2.3/etc/elasticsearch/certs
cp truststore.jks   /opt/mapr/elasticsearch/elasticsearch-6.2.3/etc/elasticsearch/keystores
cp admin-usr-keystore.jks   /opt/mapr/elasticsearch/elasticsearch-6.2.3/etc/elasticsearch/keystores
cp esekilx5646.rnd.ki.sw.ericsson.se-srvr-keystore.jks   /opt/mapr/elasticsearch/elasticsearch-6.2.3/etc/elasticsearch/keystores
cp sg2.yml   /opt/mapr/elasticsearch/elasticsearch-6.2.3/etc/elasticsearch/
cp sg_http_esekilx5646.rnd.ki.sw.ericsson.se.yml   /opt/mapr/elasticsearch/elasticsearch-6.2.3/etc/elasticsearch/
cp sg_ssl_esekilx5646.rnd.ki.sw.ericsson.se.yml   /opt/mapr/elasticsearch/elasticsearch-6.2.3/etc/elasticsearch/
cp .keystore_password   /opt/mapr/elasticsearch/elasticsearch-6.2.3/etc/elasticsearch/











