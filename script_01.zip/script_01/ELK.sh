#!/bin/bash

#Copy the below (10)keys in gp01 in /root/backup/prod/elasticsearch/ from esekilx5645.rnd.ki.sw.ericsson.se


scp /opt/mapr/elasticsearch/elasticsearch-6.2.3/etc/elasticsearch/sg/ca/es-root-ca.pem  mapr@esekilxgp01.rnd.ki.sw.ericsson.se:/root/backup/prod/elasticsearch/
scp /opt/mapr/elasticsearch/elasticsearch-6.2.3/etc/elasticsearch/sg/admin-usr-private-key.pem  mapr@esekilxgp01.rnd.ki.sw.ericsson.se:/root/backup/prod/elasticsearch/
scp -rp /opt/mapr/elasticsearch/elasticsearch-6.2.3/etc/elasticsearch/sg/admin-usr-signed.pem  mapr@esekilxgp01.rnd.ki.sw.ericsson.se:/root/backup/prod/elasticsearch/
scp -rp /opt/mapr/elasticsearch/elasticsearch-6.2.3/etc/elasticsearch/sg/truststore.jks  mapr@esekilxgp01.rnd.ki.sw.ericsson.se:/root/backup/prod/elasticsearch/
scp -rp /opt/mapr/elasticsearch/elasticsearch-6.2.3/etc/elasticsearch/sg/admin-usr-keystore.jks mapr@esekilxgp01.rnd.ki.sw.ericsson.se:/root/backup/prod/elasticsearch/
scp -rp /opt/mapr/elasticsearch/elasticsearch-6.2.3/etc/elasticsearch/sg/esekilx5646.rnd.ki.sw.ericsson.se-srvr-keystore.jks mapr@esekilxgp01.rnd.ki.sw.ericsson.se:/root/backup/prod/elasticsearch/
scp -rp /opt/mapr/elasticsearch/elasticsearch-6.2.3/etc/elasticsearch/sg/sg2.yml  mapr@esekilxgp01.rnd.ki.sw.ericsson.se:/root/backup/prod/elasticsearch/
scp -rp /opt/mapr/elasticsearch/elasticsearch-6.2.3/etc/elasticsearch/sg/sg_http_esekilx5646.rnd.ki.sw.ericsson.se.yml mapr@esekilxgp01.rnd.ki.sw.ericsson.se:/root/backup/prod/elasticsearch/
scp -rp /opt/mapr/elasticsearch/elasticsearch-6.2.3/etc/elasticsearch/sg/sg_ssl_esekilx5646.rnd.ki.sw.ericsson.se.yml mapr@esekilxgp01.rnd.ki.sw.ericsson.se:/root/backup/prod/elasticsearch/

scp -rp /opt/mapr/elasticsearch/elasticsearch-6.2.3/etc/elasticsearch/.keystore_password mapr@esekilxgp01.rnd.ki.sw.ericsson.se:/root/backup/prod/elasticsearch/

#list the files
cd /root/backup/prod/elasticsearch/

ls -ltr

# Run in 


clush -w esekilx5646.rnd.ki.sw.ericsson.se  'mkdir -p /opt/mapr/elasticsearch/elasticsearch-6.2.3/etc/elasticsearch/keystores'
clush -w esekilx5646.rnd.ki.sw.ericsson.se  'chown -R mapr:maprg /opt/mapr/elasticsearch/elasticsearch-6.2.3/etc/elasticsearch/keystores'
clush -w esekilx5646.rnd.ki.sw.ericsson.se  'mkdir -p /opt/mapr/elasticsearch/elasticsearch-6.2.3/etc/elasticsearch/certs'
clush -w esekilx5646.rnd.ki.sw.ericsson.se  'chown -R mapr:maprg /opt/mapr/elasticsearch/elasticsearch-6.2.3/etc/elasticsearch/certs'
clush -w esekilx5646.rnd.ki.sw.ericsson.se  'mkdir -p /opt/mapr/elasticsearch/elasticsearch-6.2.3/etc/elasticsearch/ca'
clush -w esekilx5646.rnd.ki.sw.ericsson.se  'chown -R mapr:maprg /opt/mapr/elasticsearch/elasticsearch-6.2.3/etc/elasticsearch/ca'



clush -w esekilx5646.rnd.ki.sw.ericsson.se --copy es-root-ca.pem  --dest /opt/mapr/elasticsearch/elasticsearch-6.2.3/etc/elasticsearch/ca
clush -w esekilx5646.rnd.ki.sw.ericsson.se --copy admin-usr-private-key.pem  --dest /opt/mapr/elasticsearch/elasticsearch-6.2.3/etc/elasticsearch/certs
clush -w esekilx5646.rnd.ki.sw.ericsson.se --copy admin-usr-signed.pem  --dest /opt/mapr/elasticsearch/elasticsearch-6.2.3/etc/elasticsearch/certs
clush -w esekilx5646.rnd.ki.sw.ericsson.se --copy truststore.jks  --dest /opt/mapr/elasticsearch/elasticsearch-6.2.3/etc/elasticsearch/keystores
clush -w esekilx5646.rnd.ki.sw.ericsson.se --copy admin-usr-keystore.jks  --dest /opt/mapr/elasticsearch/elasticsearch-6.2.3/etc/elasticsearch/keystores
clush -w esekilx5646.rnd.ki.sw.ericsson.se --copy esekilx5646.rnd.ki.sw.ericsson.se-srvr-keystore.jks  --dest /opt/mapr/elasticsearch/elasticsearch-6.2.3/etc/elasticsearch/keystores
clush -w esekilx5646.rnd.ki.sw.ericsson.se --copy sg2.yml  --dest /opt/mapr/elasticsearch/elasticsearch-6.2.3/etc/elasticsearch/
clush -w esekilx5646.rnd.ki.sw.ericsson.se --copy sg_http_esekilx5646.rnd.ki.sw.ericsson.se.yml  --dest /opt/mapr/elasticsearch/elasticsearch-6.2.3/etc/elasticsearch/
clush -w esekilx5646.rnd.ki.sw.ericsson.se --copy sg_ssl_esekilx5646.rnd.ki.sw.ericsson.se.yml  --dest /opt/mapr/elasticsearch/elasticsearch-6.2.3/etc/elasticsearch/
clush -w esekilx5646.rnd.ki.sw.ericsson.se --copy .keystore_password  --dest /opt/mapr/elasticsearch/elasticsearch-6.2.3/etc/elasticsearch/

####Copy the below (4)keys in gp01 in /root/backup/prod/fluentd/####

scp  /opt/mapr/elasticsearch/elasticsearch-6.2.3/etc/elasticsearch/sg/ca/es-root-ca.pem  mapr@esekilxgp01.rnd.ki.sw.ericsson.se:/root/backup/prod/fluentd/
scp  /opt/mapr/elasticsearch/elasticsearch-6.2.3/etc/elasticsearch/sg/fluentd-usr-signed.pem  mapr@esekilxgp01.rnd.ki.sw.ericsson.se:/root/backup/prod/fluentd/
scp  /opt/mapr/elasticsearch/elasticsearch-6.2.3/etc/elasticsearch/sg/fluentd-usr-private-key.pem  mapr@esekilxgp01.rnd.ki.sw.ericsson.se:/root/backup/prod/fluentd/
scp  /opt/mapr/elasticsearch/elasticsearch-6.2.3/etc/elasticsearch/sg/fluentd-usr-clientCombo.pem  mapr@esekilxgp01.rnd.ki.sw.ericsson.se:/root/backup/prod/fluentd/

## list files in /root/backup/prod/fluentd/

ls -ltr


clush -bg prod 'mkdir -p /opt/mapr/fluentd/fluentd-1.1.2/etc/fluentd/certs/'
clush -bg prod 'chown -R mapr:maprg /opt/mapr/fluentd/fluentd-1.1.2/etc/fluentd/certs/'
clush -bg prod 'mkdir -p /opt/mapr/fluentd/fluentd-1.1.2/etc/fluentd/ca/'
clush -bg prod 'chown -R mapr:maprg /opt/mapr/fluentd/fluentd-1.1.2/etc/fluentd/ca/'


clush -bg prod --copy es-root-ca.pem --dest /opt/mapr/fluentd/fluentd-1.1.2/etc/fluentd/ca/
clush -bg prod --copy fluentd-usr-signed.pem --dest /opt/mapr/fluentd/fluentd-1.1.2/etc/fluentd/certs/
clush -bg prod --copy fluentd-usr-private-key.pem --dest /opt/mapr/fluentd/fluentd-1.1.2/etc/fluentd/certs/
clush -bg prod --copy fluentd-usr-private-key.pem  --dest /opt/mapr/fluentd/fluentd-1.1.2/etc/fluentd/certs/

#####Copy the below (5)keys in gp01 in /root/backup/prod/kibana/

scp /opt/mapr/elasticsearch/elasticsearch-6.2.3/etc/elasticsearch/.keystore_password mapr@esekilxgp01.rnd.ki.sw.ericsson.se:/root/backup/prod/kibana/
scp  /opt/mapr/elasticsearch/elasticsearch-6.2.3/etc/elasticsearch/sg/ca/es-root-ca.pem mapr@esekilxgp01.rnd.ki.sw.ericsson.se:/root/backup/prod/kibana/
scp  /opt/mapr/elasticsearch/elasticsearch-6.2.3/etc/elasticsearch/sg/kibanaserver-usr-clientCombo.pem  mapr@esekilxgp01.rnd.ki.sw.ericsson.se:/root/backup/prod/kibana/
scp  /opt/mapr/elasticsearch/elasticsearch-6.2.3/etc/elasticsearch/sg/kibanaserver-usr-signed.pem  mapr@esekilxgp01.rnd.ki.sw.ericsson.se:/root/backup/prod/kibana/
scp  /opt/mapr/elasticsearch/elasticsearch-6.2.3/etc/elasticsearch/sg/kibanaserver-usr-private-key.pem  mapr@esekilxgp01.rnd.ki.sw.ericsson.se:/root/backup/prod/kibana/

## list files in /root/backup/prod/kibana/
ls -ltr



clush -w esekilx5645.rnd.ki.sw.ericsson.se, esekilx5646.rnd.ki.sw.ericsson.se 'mkdir -p /opt/mapr/kibana/kibana-6.2.3/config/ca/'
clush -w esekilx5645.rnd.ki.sw.ericsson.se, esekilx5646.rnd.ki.sw.ericsson.se 'chown -R mapr:maprg /opt/mapr/kibana/kibana-6.2.3/config/ca/'
clush -w esekilx5645.rnd.ki.sw.ericsson.se, esekilx5646.rnd.ki.sw.ericsson.se 'mkdir -p /opt/mapr/kibana/kibana-6.2.3/config/certs/'
clush -w esekilx5645.rnd.ki.sw.ericsson.se, esekilx5646.rnd.ki.sw.ericsson.se 'chown -R mapr:maprg /opt/mapr/kibana/kibana-6.2.3/config/certs/'

clush -w esekilx5645.rnd.ki.sw.ericsson.se, esekilx5646.rnd.ki.sw.ericsson.se --copy .keystore_password  --dest /opt/mapr/kibana/kibana-6.2.3/config/
clush -w esekilx5645.rnd.ki.sw.ericsson.se, esekilx5646.rnd.ki.sw.ericsson.se  --copy es-root-ca.pem  --dest /opt/mapr/kibana/kibana-6.2.3/config/ca/
clush -w esekilx5645.rnd.ki.sw.ericsson.se,esekilx5646.rnd.ki.sw.ericsson.se --copy kibanaserver-usr-clientCombo.pem  --dest /opt/mapr/kibana/kibana-6.2.3/config/certs/
clush -w esekilx5645.rnd.ki.sw.ericsson.se,esekilx5646.rnd.ki.sw.ericsson.se --copy kibanaserver-usr-signed.pem  --dest /opt/mapr/kibana/kibana-6.2.3/config/certs/
clush -w esekilx5645.rnd.ki.sw.ericsson.se,esekilx5646.rnd.ki.sw.ericsson.se --copy kibanaserver-usr-private-key.pem  --dest /opt/mapr/kibana/kibana-6.2.3/config/certs/

###run in all node the below command


clush -bg prod '/opt/mapr/server/configure.sh -ES esekilx5645.rnd.ki.sw.ericsson.se,esekilx5646.rnd.ki.sw.ericsson.se -R'

