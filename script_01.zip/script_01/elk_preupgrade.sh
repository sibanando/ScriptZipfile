#!/bin/bash


old_el="elasticsearch-6.2.3"
old_fld="fluentd-1.1.2"
old_kb="kibana-6.2.3"

#Copy the config files  /root/backup/MEP.6.1/elasticsearch-6.2.3/ from esekilx5645.rnd.ki.sw.ericsson.se
mkdir /root/backup/MEP-6.1/$old_el/
chmod 755 /root/backup/MEP-6.1/$old_el/
###cp -rp /opt/mapr/elasticsearch/elasticsearch-6.2.3/etc/* /root/backup/MEP.6.1/elasticsearch-6.2.3/###
cp -rp /opt/mapr/elasticsearch/$old_el/* /root/backup/MEP.6.1/$old_el/

#list the files
/bin/cd /root/backup/MEP.6.1/$old_el/

ls -ltr

####Copy the config files  in /root/backup/MEP.6.1/fluentd-1.1.2/####

mkdir /root/backup/MEP-6.1/$old_fld/
chmod 755 /root/backup/MEP-6.1/$old_fld/
####cp -rp /opt/mapr/fluentd/fluentd-1.1.2/etc/*  /root/backup/MEP.6.1/fluentd-1.1.2/###
p -rp /opt/mapr/fluentd/$old_fld/*  /root/backup/MEP.6.1/$old_fld/
#list the files
/bin/cd /root/backup/MEP.6.1/$old_fld/

ls -ltr

####Copy the config files  in /root/backup/MEP.6.1/kibana-6.2.3/####

mkdir /root/backup/MEP-6.1/$old_kb/
chmod 755 /root/backup/MEP.6-1/$old_kb/
####cp -rp /opt/mapr/kibana/kibana-6.2.3/etc/*  /root/backup/MEP.6.1/kibana-6.2.3/###
###cp -rp /opt/mapr/kibana/kibana-6.2.3/config/* /root/backup/MEP.6.1/kibana-6.2.3/##
cp -rp /opt/mapr/kibana/$old_kb/*  /root/backup/MEP.6.1/$old_kb/

#list the files
/bin/cd /root/backup/MEP-6.1/$old_kb/

ls -ltr



